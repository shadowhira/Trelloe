import Board from '~/pages/Boards/_id'
import Login from './pages/Auth/Login'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Register from '~/pages/Auth/Register'; // Trang đăng ký

function App() {
  return (
    <>
      {/* React Router Dom /boards / boards/{board_id} */}
      {/* Board Details */}
      {/* <Board /> */}
      <Router>
        <Routes>

          {/* Trang đăng nhập */}
          <Route path="/login" element={<Login />} />

          {/* Trang đăng ký */}
          <Route path='/register' element={<Register/>} />

          {/* Trang chi tiết bảng với ID */}
          <Route path="/" element={<Board />} />


        </Routes>
      </Router>
    </>
  )
}

export default App
