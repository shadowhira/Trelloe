import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [auth, setAuth] = useState(false);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();
  axios.defaults.withCredentials = true;

  useEffect(() => {
    // Kiểm tra trạng thái xác thực khi trang được tải
    axios.get('http://localhost:8017/check-auth')
      .then((res) => {
        if (res.data.Status === 'Success') {
          setAuth(true);
          navigate('/'); // Nếu đã đăng nhập, điều hướng đến trang chính
        } else {
          setAuth(false);
          setMessage(res.data.error);
        }
      })
      .catch((err) => {
        console.error('Lỗi khi kiểm tra xác thực:', err);
        setAuth(false);
        setMessage('Có lỗi xảy ra. Vui lòng thử lại sau.');
      });
  }, [navigate]); // Chỉ chạy một lần khi trang được tải

  const handleSubmit = (e) => {
    e.preventDefault();

    axios.post('http://localhost:8017/login', { email, password })
      .then((res) => {
        if (res.data.Status === 'Success') {
          navigate('/'); // Điều hướng đến trang chính khi đăng nhập thành công
        } else {
          alert(res.data.error);
        }
      })
      .catch((err) => {
        toast.error('Lỗi khi đăng nhập:', err);
        toast.error('Đăng nhập thất bại. Vui lòng thử lại.');
      });
  };

  if (auth) {
    return null; // Nếu đã đăng nhập, không hiển thị trang đăng nhập
  }

  return (
    <div className="d-flex justify-content-center align-items-center bg-primary vh-100">
      <div className="bg-white p-3 rounded w-25">
        <h2>Đăng nhập</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="email"><strong>Email</strong></label>
            <input 
              type="email"
              placeholder="Nhập email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="form-control rounded-0"
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="password"><strong>Mật khẩu</strong></label>
            <input 
              type="password"
              placeholder="Nhập mật khẩu"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="form-control rounded-0"
              required
            />
          </div>
          <button type="submit" className="btn btn-success w-100 rounded-0">Đăng nhập</button> 
          <p>Bằng cách đăng nhập, bạn đồng ý với các điều khoản và chính sách của chúng tôi.</p>
          <Link to="/register" className="btn btn-default border w-100 bg-light rounded-0 text-decoration-none">
            Tạo tài khoản
          </Link>
        </form>
      </div>
    </div>
  );
};

export default Login;