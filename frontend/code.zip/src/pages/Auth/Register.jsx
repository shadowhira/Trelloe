import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [auth, setAuth] = useState(false);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  axios.defaults.withCredentials = true;

  useEffect(() => {
    // Kiểm tra xác thực
    axios.get('/check-auth')
      .then((res) => {
        if (res.data.Status === 'Success') {
          setAuth(true);
          navigate('/'); // Nếu đã đăng nhập, điều hướng về trang chính
        } else {
          setAuth(false);
          setMessage(res.data.error);
        }
      })
      .catch((err) => {
        toast.error('Lỗi khi kiểm tra xác thực:', err);
        setAuth(false);
        setMessage('Có lỗi xảy ra. Vui lòng thử lại sau.');
      });
  }, [navigate]); // Chạy khi trang được tải

  const handleSubmit = (e) => {
    e.preventDefault();

    axios.post('http://localhost:8017/register', { name, email, password })
      .then((res) => {
        if (res.data.Status === 'Success') {
          navigate('/login'); // Điều hướng đến trang đăng nhập sau khi đăng ký thành công
        } else {
          toast.error(res.data.error);
        }
      })
      .catch((err) => {
        console.error('Lỗi khi đăng ký:', err);
        toast.error('Đăng ký thất bại. Vui lòng thử lại.');
      });
  };

  if (auth) {
    return null; // Nếu đã đăng nhập, không hiển thị trang đăng ký
  }

  return (
    <div className="d-flex justify-content-center align-items-center bg-primary vh-100">
      <div className="bg-white p-4 rounded w-25">
        <h2>Đăng ký</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="name"><strong>Tên</strong></label>
            <input 
              type="text"
              placeholder="Nhập tên"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="form-control rounded-0"
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="email"><strong>Email</strong></label>
            <input 
              type="email"
              placeholder="Nhập email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="form-control rounded-0"
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="password"><strong>Mật khẩu</strong></label>
            <input 
              type="password"
              placeholder="Nhập mật khẩu"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="form-control rounded-0"
              required
            />
          </div>
          <button type="submit" className="btn btn-success w-100 rounded-0">Đăng ký</button>
          <p className="mt-2">Bằng cách đăng ký, bạn đồng ý với các điều khoản và chính sách của chúng tôi.</p>
          <Link to="/login" className="btn btn-light border w-100 rounded-0 text-decoration-none">
            Đăng nhập
          </Link>
        </form>
      </div>
    </div>
  );
};

export default Register;